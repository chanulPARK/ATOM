$(function(){
  $('#menu').metisMenu({
    toggle:false
  });
});
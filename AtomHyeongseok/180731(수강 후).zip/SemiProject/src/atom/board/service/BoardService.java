package atom.board.service;
import static common.JDBCTemplate.*;
import java.sql.Connection;
import java.util.List;
import atom.board.dao.BoardDAO;
import atom.board.vo.*;

public class BoardService {
	private Connection conn;
	
	public Board selectOne(int boardNo, boolean hasRead) {
		conn = getConnection();
		Board b = new BoardDAO().selectOne(conn, boardNo);
		int result = 0;
		if(b!=null) {
			if(!hasRead) {
				result = new BoardDAO()
						.insertBoardCount(conn, boardNo);
				if(result>0)
					commit(conn);
				else
					rollback(conn);
			}
		}
		close(conn);
		return b;
	}
	
	public int insertBoard(Board b) {
		conn = getConnection();
		int result = new BoardDAO().insertBoard(conn, b);
		if(result>0)
			commit(conn);
		else
			rollback(conn);
		close(conn);
		return result;
	}
	
	public int updateBoard(Board b) {
		conn = getConnection();
		int result = new BoardDAO().updateBoard(conn, b);
		if(result>0)
			commit(conn);
		else
			rollback(conn);
		close(conn);
		return result;
	}
	
	public int deleteBoard(Board b) {
		conn = getConnection();
		int result = new BoardDAO().deleteBoard(conn, b);
		if(result>0)
			commit(conn);
		else
			rollback(conn);
		close(conn);
		return result;
	}
	
	public List<Board> selectBoardList(int cPage, int numPerPage, String boardCode){
		conn = getConnection();
		List<Board> list = new BoardDAO()
				.selectBoardList(conn, cPage, numPerPage, boardCode);
		close(conn);
		return list;
	}
	
	public int selectBoardCount(String boardCode) {
		conn = getConnection();
		int result = new BoardDAO().selectBoardCount(conn, boardCode);
		if(result>0)
			commit(conn);
		else
			rollback(conn);
		close(conn);
		return result;
	}
	
	public List<BoardCode> selectBoardCodeList()
	{
		conn = getConnection();
		List<BoardCode> list=new BoardDAO().selectBoardCodeList(conn);
		close(conn);
		return list;
	}
	
	public int insertBoardCodeList(BoardCode bc, int no) {
		conn = getConnection();
		int result = new BoardDAO().insertBoardCodeList(conn, bc, no);
		if(result>0)
			commit(conn);
		else
			rollback(conn);
		close(conn);
		return result;
	}
	
	public int deleteBoardCodeList(BoardCode bc) {
		conn = getConnection();
		int result = new BoardDAO().deleteBoardCodeList(conn, bc);
		if(result>0)
			commit(conn);
		else
			rollback(conn);
		close(conn);
		return result;
	}
}

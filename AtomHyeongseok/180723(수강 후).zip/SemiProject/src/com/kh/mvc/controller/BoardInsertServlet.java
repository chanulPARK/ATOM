package com.kh.mvc.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.kh.mvc.board.service.BoardService;
import com.kh.mvc.board.vo.Board;

/**
 * Servlet implementation class BoardInsertServlet
 */
@WebServlet("/board/boardInsert.jsp")
public class BoardInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BoardInsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("BoardInsertServlet 클래스에서 실행하였습니다.");
		Board b = (Board)request.getAttribute("board");
		int result = new BoardService().insertBoard(b);
		
		String msg="";
		String loc="";
		String view="/views";
		if(result>0) {
			msg="게시글이 등록되었습니다.";
			System.out.println(msg);
			loc="/views/board/boardView.jsp";
		}
		else {
			msg="게시글 등록을 실패하였습니다.";
			System.out.println(msg);
			loc="/views/common/msg.jsp";
		}
		request.setAttribute("msg", msg);
		request.setAttribute("loc", loc);
		request.getRequestDispatcher(view).forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

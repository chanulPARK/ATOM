package com.kh.mvc.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.kh.mvc.board.service.BoardService;
import com.kh.mvc.board.vo.Board;

/**
 * Servlet implementation class BoardDeleteServlet
 */
@WebServlet("/boardDelete.jsp")
public class BoardDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BoardDeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("BoardDeleteServlet 클래스에서 실행하였습니다.");
		Board b = (Board)request.getAttribute("board");
		int result = new BoardService().deleteBoard(b);
		
		String msg = "";
		String loc = "";
		String view = "/views/board/boardDelete.jsp";
		if(result>0) {
			msg="정상적으로 삭제되었습니다.";
			System.out.println(msg);
			loc="/views/board/boardView.jsp";
		}
		else {
			msg="게시글 삭제를 할 수 없습니다.";
			System.out.println(msg);
			loc="/views/common/msg.jsp";
		}
		request.setAttribute("msg", msg);
		request.setAttribute("loc", loc);
		request.getRequestDispatcher(view).forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

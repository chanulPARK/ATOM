// $(function() {
//   $('#submenu1').metisMenu({
//     toggle:false
//   });
// });
// $(function() {
//   $('#submenu2').metisMenu({
//     toggle:false
//   });
// });
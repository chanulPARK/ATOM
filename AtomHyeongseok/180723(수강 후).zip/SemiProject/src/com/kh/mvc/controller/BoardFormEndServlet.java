package com.kh.mvc.controller;
import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

/**
 * Servlet implementation class BoardFormEndServlet
 */
@WebServlet("/board/boardFormEnd")
public class BoardFormEndServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BoardFormEndServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 파일이 제대로 들어왔는지 확인한다. 여기서는 miltipart로 제대로 갔는지를 말한다.
		if(ServletFileUpload.isMultipartContent(request)) {
			request.setAttribute("msg",
						"게시판 작성 오류[form : enctype 관리자에게 문의하시오.]");
			request.setAttribute("loc", "/");
			request.getRequestDispatcher("/views/common/msg.jsp")
					.forward(request, response);
			return;
		}
		// 저장 경로를 설정하기에 앞서, 저장할 곳의 폴더를 생성해야 한다.
		String root = getServletContext().getRealPath("/");
		String saveDir = root+"upload"+File.separator+"board";	// 저장 경로 설정 완료
		// 파일 크기를 설정한다.
		int maxSize = 1024*1024*1024*10;		// 10GB(10 기가바이트)
		// 파일을 업로드하는 객체 생성
//		MultipartRequest mpReq
//			= new MultipartRequest(request, saveDir, maxSize, "UTF-8",
//					new DefaultFileRenamePolicy());	// 파일 업로드 완료
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
